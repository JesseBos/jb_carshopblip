description 'GTA V Aangepast Blips'
client_script 'blips.lua'