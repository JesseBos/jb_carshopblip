description 'jb_autodealer'
version '0.0.1'
client_scripts {
	'client/blips.lua'
}